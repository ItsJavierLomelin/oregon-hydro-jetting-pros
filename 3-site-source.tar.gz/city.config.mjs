export const ACTIVE_CITY = 'oregon-oh';
